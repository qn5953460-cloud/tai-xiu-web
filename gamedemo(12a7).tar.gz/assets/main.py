# -*- coding: utf-8 -*-
import asyncio
import random
import pygame
import socketio

# --- 1. KHỞI TẠO SOCKET.IO CLIENT ---
sio = socketio.AsyncClient()

# --- 2. KHỞI TẠO PYGAME (ĐÃ BỎ ÂM THANH) ---
pygame.init()

SCREEN_WIDTH = 1250
SCREEN_HEIGHT = 750
GAME_AREA_WIDTH = 930
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("CASINO - TAI XIU ONLINE")
clock = pygame.time.Clock()

font_title = pygame.font.Font(None, 30)
font_big_bet = pygame.font.Font(None, 56)
font_timer = pygame.font.Font(None, 40)
font_text = pygame.font.Font(None, 22)
font_chip = pygame.font.Font(None, 15)
font_history = pygame.font.Font(None, 14)
font_chat = pygame.font.Font(None, 14)
font_emoji = pygame.font.Font(None, 16)

# --- 3. TRẠNG THÁI GAME ---
player_balance = 50000000     
BOWL_Y = 90                     
lid_y = BOWL_Y + 10          
is_dragging_lid = False        
drag_offset_y = 0              

BG_COLOR = (12, 75, 49)        
TEXT_GOLD = (235, 179, 58)    
WHITE = (255, 255, 255)
BLACK = (20, 20, 20)
GRAY = (50, 50, 50)
LIGHT_GRAY = (200, 200, 200)

total_bet = 0                  
selected_side = None          
time_left = 15                 
dice_results = [1, 1, 1]      
game_status = "DANG KET NOI SERVER..." 
status_color = WHITE
is_covered = True             
waiting_for_open = False      
history_results = []          
online_count = 1

chat_messages = [
    ("He thong", "Dang ket noi toi may chủ...", (255, 215, 0)),
]
user_chat_input = ""
chat_input_active = False

QUICK_TEXTS = ["All in!", "Theo Tai!", "Be Xiu!", "Cau dep!"]
QUICK_EMOJIS = ["<3", "LIKE", "HAHA", "MONEY", "GEM"]

def add_chat(sender, message, color=(220, 220, 220)):
    chat_messages.append((sender, message, color))
    if len(chat_messages) > 14:
        chat_messages.pop(0)

CHIP_VALUES = [1000, 5000, 10000, 50000, 100000, 500000, 1000000, 5000000, 10000000, 50000000]

def format_currency_short(amount):
    if amount == 0: return "0"
    if amount >= 1000000:
        val = amount / 1000000
        return f"{int(val)}M" if val.is_integer() else f"{val:.1f}M"
    elif amount >= 1000:
        val = amount / 1000
        return f"{int(val)}k" if val.is_integer() else f"{val:.1f}k"
    return str(amount)

# --- 4. SOCKET.IO EVENT HANDLERS (LẮNG NGHE TỪ SERVER) ---
@sio.event
async def connect():
    global game_status, status_color
    game_status = "DANG DAT CUOC..."
    status_color = WHITE
    add_chat("He thong", "Ket nối thành công tới phòng Tài Xỉu Online!", (255, 215, 0))

@sio.event
async def disconnect():
    global game_status, status_color
    game_status = "MAT KET NOI VOI SERVER!"
    status_color = (220, 53, 69)
    add_chat("He thong", "Mất kết nối với máy chủ!", (255, 100, 100))

@sio.on('sync_game_state')
async def on_sync_state(data):
    """Nhận trạng thái đồng bộ từ server (thời gian, trạng thái, số lượng online)"""
    global time_left, waiting_for_open, online_count, dice_results, is_covered, lid_y
    time_left = data.get('time_left', 15)
    waiting_for_open = data.get('waiting_for_open', False)
    online_count = data.get('online_count', 1)
    if 'dice' in data and data['dice']:
        dice_results = data['dice']

@sio.on('game_result')
async def on_game_result(data):
    """Nhận kết quả chung từ server và tính toán thắng thua cho ví tiền"""
    global player_balance, game_status, status_color, history_results, dice_results, waiting_for_open, is_covered
    dice_results = data.get('dice', [1, 1, 1])
    total_score = sum(dice_results)
    result_side = data.get('result_side', 'TAI')
    hist_char = data.get('hist_char', 'T')
    
    history_results.append(hist_char)
    if len(history_results) > 16:
        history_results.pop(0)

    waiting_for_open = True
    is_covered = False

    global total_bet, selected_side
    if selected_side is None or total_bet == 0:
        game_status = f"KET QUA: {total_score} DIEM ({result_side})"
        status_color = WHITE
    elif selected_side == result_side:
        house_fee = int(total_bet * 0.10)
        net_win = total_bet - house_fee
        player_balance += net_win
        game_status = f"THANG +{format_currency_short(net_win)}d!"
        status_color = (40, 167, 69)
    else:
        player_balance -= total_bet
        game_status = f"THUA -{format_currency_short(total_bet)}d! ({total_score} DIEM)"
        status_color = (220, 53, 69)
    
    # Reset cược cho ván sau sau vài giây
    await asyncio.sleep(3)
    total_bet = 0
    selected_side = None
    is_covered = True
    waiting_for_open = False
    lid_y = BOWL_Y + 10
    game_status = "DANG DAT CUOC..."
    status_color = WHITE

@sio.on('new_chat')
async def on_new_chat(data):
    add_chat(data['sender'], data['message'], tuple(data.get('color', (220, 220, 220))))

# --- GIAO DIỆN & VÙNG CLICK ---
rect_xiu = pygame.Rect(70, 190, 330, 150)
rect_tai = pygame.Rect(530, 190, 330, 150)

chip_rects = []
chip_w, chip_h = 80, 38
start_x, start_y = (GAME_AREA_WIDTH - (5 * 90)) // 2, 560
for i, value in enumerate(CHIP_VALUES):
    row = i // 5
    col = i % 5
    chip_rects.append((pygame.Rect(start_x + col * 90, start_y + row * 48, chip_w, chip_h), value))

btn_clear_rect = pygame.Rect(260, 675, 150, 40)
btn_confirm_rect = pygame.Rect(480, 675, 150, 40)
btn_open_rect = pygame.Rect(GAME_AREA_WIDTH//2 - 70, BOWL_Y + 115, 140, 42) 

chat_panel_rect = pygame.Rect(950, 20, 280, 710)
chat_input_rect = pygame.Rect(960, 650, 260, 38)

quick_text_rects = []
for idx, txt in enumerate(QUICK_TEXTS):
    rect = pygame.Rect(960 + idx * 65, 560, 60, 28)
    quick_text_rects.append((rect, txt))

quick_emoji_rects = []
for idx, emo in enumerate(QUICK_EMOJIS):
    rect = pygame.Rect(960 + idx * 52, 598, 48, 28)
    quick_emoji_rects.append((rect, emo))

def draw_dice(screen, center_x, center_y, value):
    size = 46
    rect = pygame.Rect(center_x - size//2, center_y - size//2, size, size)
    pygame.draw.rect(screen, WHITE, rect, border_radius=8)
    pygame.draw.rect(screen, BLACK, rect, width=2, border_radius=8)
    dots = {
        1: [(0,0)], 2: [(-11,-11), (11,11)], 3: [(-11,-11), (0,0), (11,11)],
        4: [(-11,-11), (-11,11), (11,-11), (11,11)], 5: [(-11,-11), (-11,11), (0,0), (11,-11), (11,11)],
        6: [(-11,-11), (-11,0), (-11,11), (11,-11), (11,0), (11,11)]
    }
    for dx, dy in dots[value]:
        color = (220, 53, 69) if value == 1 else BLACK
        radius = 5 if value == 1 else 4
        pygame.draw.circle(screen, color, (center_x + dx, center_y + dy), radius)

# --- 5. VÒNG LẶP CHÍNH ---
async def main():
    global online_count, dice_results, time_left, waiting_for_open, is_covered
    global game_status, status_color, total_bet, selected_side, lid_y
    global user_chat_input, chat_input_active, is_dragging_lid, drag_offset_y

    try:
        await sio.connect('http://localhost:8080')
    except Exception as e:
        print("Lỗi kết nối server:", e)

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN and chat_input_active:
                if event.key == pygame.K_RETURN:
                    msg_clean = user_chat_input.strip()
                    if msg_clean:
                        await sio.emit('send_chat', {'message': msg_clean})
                        user_chat_input = ""
                elif event.key == pygame.K_BACKSPACE:
                    user_chat_input = user_chat_input[:-1]
                else:
                    if len(user_chat_input) < 25:
                        user_chat_input += event.unicode

            if event.type == pygame.MOUSEBUTTONDOWN:
                chat_input_active = chat_input_rect.collidepoint(event.pos)

                for rect, txt in quick_text_rects:
                    if rect.collidepoint(event.pos):
                        await sio.emit('send_chat', {'message': txt})

                for rect, emo in quick_emoji_rects:
                    if rect.collidepoint(event.pos):
                        await sio.emit('send_chat', {'message': emo})

                if time_left > 0 and not waiting_for_open:
                    if rect_xiu.collidepoint(event.pos):
                        selected_side = "XIU"
                    elif rect_tai.collidepoint(event.pos):
                        selected_side = "TAI"
                    
                    for rect, value in chip_rects:
                        if rect.collidepoint(event.pos):
                            if total_bet + value <= player_balance:
                                total_bet += value
                    
                    if btn_clear_rect.collidepoint(event.pos):
                        total_bet = 0
                        selected_side = None
                        
                    if btn_confirm_rect.collidepoint(event.pos):
                        if selected_side and total_bet > 0:
                            await sio.emit('place_bet', {'side': selected_side, 'amount': total_bet})
                            game_status = "DA GUI CUOC LEN SERVER!"

        # --- RENDER GIAO DIỆN ---
        screen.fill(BG_COLOR)
        pygame.draw.line(screen, (30, 100, 70), (GAME_AREA_WIDTH, 0), (GAME_AREA_WIDTH, SCREEN_HEIGHT), 3)

        online_box = pygame.Rect(60, 20, 150, 35)
        pygame.draw.rect(screen, (15, 30, 20), online_box, border_radius=8)
        pygame.draw.rect(screen, (100, 255, 100), online_box, width=1, border_radius=8)
        txt_online = font_chip.render(f"ONLINE: {online_count}", True, (100, 255, 100))
        screen.blit(txt_online, txt_online.get_rect(center=online_box.center))

        timer_box = pygame.Rect(60, 75, 110, 75)
        pygame.draw.rect(screen, (20, 30, 25), timer_box, border_radius=12)
        pygame.draw.rect(screen, TEXT_GOLD, timer_box, width=2, border_radius=12)
        lbl_timer = font_chip.render("THOI GIAN", True, LIGHT_GRAY)
        screen.blit(lbl_timer, (timer_box.centerx - lbl_timer.get_width()//2, timer_box.y + 8))
        timer_text = str(time_left) if not waiting_for_open else "0"
        timer_surf = font_timer.render(timer_text, True, (255, 230, 0))
        screen.blit(timer_surf, (timer_box.centerx - timer_surf.get_width()//2, timer_box.y + 28))

        bowl_rect = pygame.Rect(GAME_AREA_WIDTH//2 - 110, BOWL_Y, 220, 85)
        pygame.draw.ellipse(screen, GRAY, bowl_rect)
        pygame.draw.ellipse(screen, BLACK, bowl_rect, width=2)
        
        if not is_covered:
            draw_dice(screen, GAME_AREA_WIDTH//2 - 50, BOWL_Y + 42, dice_results[0])
            draw_dice(screen, GAME_AREA_WIDTH//2, BOWL_Y + 42, dice_results[1])
            draw_dice(screen, GAME_AREA_WIDTH//2 + 50, BOWL_Y + 42, dice_results[2])
            
        if is_covered:
            pygame.draw.ellipse(screen, (190, 140, 40), (GAME_AREA_WIDTH//2 - 75, lid_y, 150, 65))
            pygame.draw.ellipse(screen, TEXT_GOLD, (GAME_AREA_WIDTH//2 - 75, lid_y, 150, 65), width=3)

        xiu_bg = (180, 50, 60) if selected_side == "XIU" else (30, 45, 40)
        pygame.draw.rect(screen, xiu_bg, rect_xiu, border_radius=15)
        pygame.draw.rect(screen, WHITE, rect_xiu, width=3, border_radius=15)
        screen.blit(font_big_bet.render("XIU", True, WHITE), (rect_xiu.centerx - 35, rect_xiu.y + 18))
        screen.blit(font_text.render("3 - 10", True, TEXT_GOLD), (rect_xiu.centerx - 25, rect_xiu.y + 92))

        tai_bg = (40, 100, 180) if selected_side == "TAI" else (30, 45, 40)
        pygame.draw.rect(screen, tai_bg, rect_tai, border_radius=15)
        pygame.draw.rect(screen, WHITE, rect_tai, width=3, border_radius=15)
        screen.blit(font_big_bet.render("TAI", True, WHITE), (rect_tai.centerx - 30, rect_tai.y + 18))
        screen.blit(font_text.render("11 - 18", True, TEXT_GOLD), (rect_tai.centerx - 30, rect_tai.y + 92))

        status_surf = font_text.render(game_status, True, status_color)
        screen.blit(status_surf, (GAME_AREA_WIDTH//2 - status_surf.get_width()//2, 355))
        
        bet_surf = font_title.render(f"TIEN CUOC: {format_currency_short(total_bet)}d", True, TEXT_GOLD)
        screen.blit(bet_surf, (GAME_AREA_WIDTH//2 - bet_surf.get_width()//2, 395))
        
        balance_box = pygame.Rect(GAME_AREA_WIDTH - 250, 20, 230, 45)
        pygame.draw.rect(screen, (15, 30, 20), balance_box, border_radius=8)
        pygame.draw.rect(screen, TEXT_GOLD, balance_box, width=1, border_radius=8)
        balance_surf = font_text.render(f"Vi: {format_currency_short(player_balance)}d", True, (100, 255, 100))
        screen.blit(balance_surf, balance_surf.get_rect(center=balance_box.center))

        lbl_hist = font_chip.render("LICH SU PHIEN:", True, LIGHT_GRAY)
        screen.blit(lbl_hist, (70, 442))
        hist_container_rect = pygame.Rect(60, 465, 800, 50)
        pygame.draw.rect(screen, (20, 35, 25), hist_container_rect, border_radius=8)
        
        for idx, res in enumerate(history_results):
            circle_x = 90 + idx * 46
            circle_color = (40, 100, 180) if res == "T" else (180, 50, 60)
            pygame.draw.circle(screen, circle_color, (circle_x, 490), 16)
            screen.blit(font_history.render(res, True, WHITE), (circle_x - 4, 483))

        for rect, value in chip_rects:
            pygame.draw.rect(screen, TEXT_GOLD, rect, border_radius=8)
            screen.blit(font_chip.render(format_currency_short(value), True, BLACK), (rect.x + 15, rect.y + 12))
            
        pygame.draw.rect(screen, (220, 53, 69), btn_clear_rect, border_radius=8)
        screen.blit(font_text.render("XOA CUOC", True, WHITE), (btn_clear_rect.x + 30, btn_clear_rect.y + 10))
        
        pygame.draw.rect(screen, (0, 123, 255), btn_confirm_rect, border_radius=8)
        screen.blit(font_text.render("XAC NHAN", True, WHITE), (btn_confirm_rect.x + 30, btn_confirm_rect.y + 10))

        # Khung Chat
        pygame.draw.rect(screen, (15, 25, 20), chat_panel_rect, border_radius=12)
        screen.blit(font_text.render("CHAT TRUC TUYEN", True, TEXT_GOLD), (980, 32))

        chat_y = 70
        for sender, msg, col in chat_messages[-13:]:
            screen.blit(font_chat.render(f"{sender}: ", True, TEXT_GOLD), (965, chat_y))
            screen.blit(font_chat.render(msg, True, col), (1015, chat_y))
            chat_y += 33

        for rect, txt in quick_text_rects:
            pygame.draw.rect(screen, (30, 60, 45), rect, border_radius=6)
            screen.blit(font_chip.render(txt, True, WHITE), (rect.x + 8, rect.y + 6))

        for rect, emo in quick_emoji_rects:
            pygame.draw.rect(screen, (35, 55, 35), rect, border_radius=6)
            screen.blit(font_emoji.render(emo, True, WHITE), (rect.x + 6, rect.y + 6))

        pygame.draw.rect(screen, TEXT_GOLD if chat_input_active else GRAY, chat_input_rect, width=2, border_radius=8)
        txt_input_val = user_chat_input if user_chat_input else ("Nhap tin nhan..." if not chat_input_active else "|")
        screen.blit(font_chat.render(txt_input_val, True, WHITE if user_chat_input else GRAY), (chat_input_rect.x + 10, chat_input_rect.y + 9))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    await sio.disconnect()
    pygame.quit()

asyncio.run(main())